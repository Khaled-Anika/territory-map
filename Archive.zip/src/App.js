// import logo from './logo.svg';
import './App.css';
import mapboxgl from '!mapbox-gl'; // eslint-disable-line import/no-webpack-loader-syntax
import { useEffect, useRef, useState } from 'react';

mapboxgl.accessToken = 'pk.eyJ1IjoiYW5pa2FraGFsZWQiLCJhIjoiY2xiMGx6a2htMThoeTNxcHU0bmlwYzZhbSJ9.ZO3hYO4CYqJNhkTPQXMXzA';

function App() {
  // const map = useRef(null);
  const [counter, setCounter] = useState(0);
  console.log("outside useeffect");
  
  useEffect(() => {
    // if (map.current) return;
    const map = new mapboxgl.Map({
      container: 'map',
      // Choose from Mapbox's core styles, or make your own style with Mapbox Studio
      style: 'mapbox://styles/mapbox/streets-v12', //'mapbox://styles/anikakhaled/clb1wtx0900ed15o2l0sjxhbc', 
      center: [-98, 38.88],
      minZoom: 2,
      zoom: 3
    });
    
    console.log("counter", counter);
    setCounter(counter + 1);

    // Disable default box zooming.
    map.boxZoom.disable();

    // Create a popup, but don't add it to the map yet.
    const popup = new mapboxgl.Popup({
      closeButton: true
    });

    const locData = [
      {
        territory: "A",
        Name: "Schleswig-Holstein"
      }, {
        territory: "A",
        Name: "Niedersachsen"
      }, {
        territory: "A",
        Name: "Nordrhein-Westfalen"
      }, {
        territory: "B",
        Name: "Rheinland-Pfalz"
      }, {
        territory: "B",
        Name: "Baden-Württemberg"
      }, {
        territory: "B",
        Name: "Saarland"
      }, {
        territory: "X",
        Name: "Rheinland-Pfalz"
      }, {
        territory: "X",
        Name: "Hessen"
      }
    ];

    map.on('load', () => {
      const canvas = map.getCanvasContainer();

      // Variable to hold the starting xy coordinates
      // when `mousedown` occured.
      let start;

      // Variable to hold the current xy coordinates
      // when `mousemove` or `mouseup` occurs.
      let current;

      // Variable for the draw box element.
      let box;

      // Add a custom vector tileset source. The tileset used in
      // this example contains a feature for every county in the U.S.
      // Each county contains four properties. For example:
      // {
      //     COUNTY: "Uintah County",
      //     FIPS: 49047,
      //     median-income: 62363,
      //     population: 34576
      // }
      const url = 'mapbox://anikakhaled.6mvcm5x4';

      map.addSource('counties', {
        'type': 'vector',
        'url': url
      });

      map.addLayer(
        {
          'id': 'counties',
          'type': 'fill',
          'source': 'counties',
          'source-layer': 'Germany_divisions-d0c0n8',
          'paint': {
            'fill-outline-color': 'rgba(0,0,0,0.1)',
            'fill-color': 'rgba(0,0,0,0.1)'
          }
        },
        // Place polygons under labels, roads and buildings.
        'building'
      );

      const sourceFeatures = map.querySourceFeatures("counties", {
        sourceLayer: 'Germany_divisions-d0c0n8'

      });
      console.log('source features', sourceFeatures);

      map.addLayer(
        {
          'id': 'counties-highlighted',
          'type': 'fill',
          'source': 'counties',
          'source-layer': 'Germany_divisions-d0c0n8',//'USA_0-dyrsfv',
          'paint': {
            'fill-outline-color': '#484896',
            'fill-color': '#6e599f',
            'fill-opacity': 0.75
          },
          'filter': ['in', 'Name', '']
        },
        // Place polygons under labels, roads and buildings.
        'building'
      );

      map.addLayer(
        {
          'id': 'counties-highlighted-2',
          'type': 'fill',
          'source': 'counties',
          'source-layer': 'Germany_divisions-d0c0n8',//'USA_0-dyrsfv',
          'paint': {
            'fill-outline-color': '#484896',
            'fill-color': '#DC143C',
            'fill-opacity': 0.75
          },
          'filter': ['in', 'Description', '']
        },
        // Place polygons under labels, roads and buildings.
        'building'
      );

      // Set `true` to dispatch the event before other functions
      // call it. This is necessary for disabling the default map
      // dragging behaviour.
      canvas.addEventListener('mousedown', mouseDown, true);

      // Return the xy coordinates of the mouse position
      function mousePos(e) {
        const rect = canvas.getBoundingClientRect();
        return new mapboxgl.Point(
          e.clientX - rect.left - canvas.clientLeft,
          e.clientY - rect.top - canvas.clientTop
        );
      }

      function mouseDown(e) {
        // Continue the rest of the function if the shiftkey is pressed.
        if (!(e.shiftKey && e.button === 0)) return;

        // Disable default drag zooming when the shift key is held down.
        map.dragPan.disable();

        // Call functions for the following events
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
        document.addEventListener('keydown', onKeyDown);

        // Capture the first xy coordinates
        start = mousePos(e);
      }

      function onMouseMove(e) {
        // Capture the ongoing xy coordinates
        current = mousePos(e);

        // Append the box element if it doesnt exist
        if (!box) {
          box = document.createElement('div');
          box.classList.add('boxdraw');
          canvas.appendChild(box);
        }

        const minX = Math.min(start.x, current.x),
          maxX = Math.max(start.x, current.x),
          minY = Math.min(start.y, current.y),
          maxY = Math.max(start.y, current.y);

        // Adjust width and xy position of the box element ongoing
        const pos = `translate(${minX}px, ${minY}px)`;
        box.style.transform = pos;
        box.style.width = maxX - minX + 'px';
        box.style.height = maxY - minY + 'px';
      }

      function onMouseUp(e) {
        // Capture xy coordinates
        finish([start, mousePos(e)]);
      }

      function onKeyDown(e) {
        // If the ESC key is pressed
        if (e.keyCode === 27) finish();
      }

      function finish(bbox) {
        console.log("box", bbox);
        // Remove these events now that finish has been called.
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('keydown', onKeyDown);
        document.removeEventListener('mouseup', onMouseUp);

        if (box) {
          box.parentNode.removeChild(box);
          box = null;
        }

        // If bbox exists. use this value as the argument for `queryRenderedFeatures`
        if (bbox) {
          const features = map.queryRenderedFeatures(bbox, {
            layers: ['counties']
          });
          console.log("features", features);
          if (features.length >= 1000) {
            return window.alert('Select a smaller number of features');
          }

          // Run through the selected features and set a filter
          // to match features with unique FIPS codes to activate
          // the `counties-highlighted` layer.

          const features1 = features.filter((feature) => feature.properties.Name !== "Schleswig-Holstein");
          const param1 = features1.map((feature) => feature.properties.Name);
          map.setFilter('counties-highlighted', ['in', 'Name', ...param1]);

          const features2 = features.filter((feature) => feature.properties.Description === "Land-Edited");
          console.log("mapped feature", features2);
          const param2 = features2.map((feature) => feature.properties.Description);
          map.setFilter('counties-highlighted-2', ['in', 'Description', ...param2]);

        }

        map.dragPan.enable();
      }

      map.on('mousemove', (e) => {
        const features = map.queryRenderedFeatures(e.point, {
          layers: ['counties-highlighted']
        });

        // Change the cursor style as a UI indicator.
        map.getCanvas().style.cursor = features.length ? 'pointer' : '';

        if (!features.length) {
          popup.remove();
          return;
        }

        popup
          .setLngLat(e.lngLat)
          .setText(features[0].properties.COUNTRY)
          .addTo(map);
      });
    });
  }, []);

  return (
    <div id="map"></div>
  );
}

export default App;
